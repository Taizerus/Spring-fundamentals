package com.pluralsight.service;

import com.pluralsight.entity.Ticket;

import java.util.List;

public interface TicketService {
    List<Ticket> listTickets();
}


